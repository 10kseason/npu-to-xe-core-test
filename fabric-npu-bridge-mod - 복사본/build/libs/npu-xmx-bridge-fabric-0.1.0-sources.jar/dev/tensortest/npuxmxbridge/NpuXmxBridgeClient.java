package dev.tensortest.npuxmxbridge;

import java.lang.reflect.Method;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NpuXmxBridgeClient implements ClientModInitializer {
	public static final String MOD_ID = "npu_xmx_bridge";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	private static final long UPDATE_INTERVAL_MS = Long.getLong("npuxmxbridge.intervalMs", 150L);
	private static final int UPDATE_EVERY_N_FRAMES = Math.max(1, Integer.getInteger("npuxmxbridge.updateEveryNFrames", 4));
	private static final int WARMUP_REQUESTS = Math.max(0, Integer.getInteger("npuxmxbridge.warmupRequests", 3));
	private static final int MAX_ASSIST_AGE_FRAMES = Math.max(1, Integer.getInteger("npuxmxbridge.maxAssistAgeFrames", 10));
	private static final double MIN_POSITION_DELTA = getDoubleProperty("npuxmxbridge.minPositionDelta", 0.75);
	private static final double MIN_ANGLE_DELTA = getDoubleProperty("npuxmxbridge.minAngleDelta", 3.0);
	private static final int SHADER_TILE_SIZE = Integer.getInteger("npuxmxbridge.shaderTileSize", 32);
	private static final int SHADER_PREVIEW_SCALE = Integer.getInteger("npuxmxbridge.shaderPreviewScale", 6);
	private static final boolean SHOW_PREVIEW_HUD = Boolean.getBoolean("npuxmxbridge.showPreviewHud");
	private static final boolean USE_VANILLA_POST_EFFECT = Boolean.getBoolean("npuxmxbridge.useVanillaPostEffect");
	private static final int NEUTRAL_ASSIST_ABGR = 0x00808080;
	private static final class_2960 SHADER_TEXTURE_ID = class_2960.method_60655(MOD_ID, "shader_preview");
	private static final class_2960 HUD_LAYER_ID = class_2960.method_60655(MOD_ID, "shader_preview_hud");
	private static final class_2960 POST_EFFECT_ID = class_2960.method_60655(MOD_ID, "npu_assist");
	private static final Method SET_POST_EFFECT_METHOD = resolveSetPostEffectMethod();

	private static final class_304 RUN_SAMPLE_KEY = KeyBindingHelper.registerKeyBinding(
		new class_304(
			"key.npu_xmx_bridge.run_sample",
			class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_N,
			class_304.class_11900.field_62556
		)
	);
	private static final AtomicBoolean REQUEST_IN_FLIGHT = new AtomicBoolean(false);
	private static final NpuBridgeClient BRIDGE_CLIENT = createBridgeClient();
	private static final ExecutorService BRIDGE_EXECUTOR = Executors.newSingleThreadExecutor(runnable -> {
		Thread thread = new Thread(runnable, "npu-xmx-bridge-worker");
		thread.setDaemon(true);
		return thread;
	});
	private static final Object TEXTURE_LOCK = new Object();
	private static volatile long lastDispatchAtNanos;
	private static volatile OverlayStatus overlayStatus = new OverlayStatus("", class_124.field_1080);
	private static volatile long frameSequence;
	private static volatile class_1043 shaderTexture;
	private static volatile int shaderTextureWidth = SHADER_TILE_SIZE * Math.max(1, SHADER_PREVIEW_SCALE);
	private static volatile int shaderTextureHeight = SHADER_TILE_SIZE * Math.max(1, SHADER_PREVIEW_SCALE);
	private static volatile boolean shaderFrameReady;
	private static volatile class_2960 previousPostEffectId;
	private static volatile AssistTelemetryLogger telemetryLogger;
	private static volatile boolean telemetryInitFailed;
	private static volatile long lastTelemetryHeartbeatAtNanos;
	private static volatile AssistMode assistMode = AssistMode.OFF;
	private static volatile int warmupRemaining;
	private static volatile long assistGeneration;
	private static volatile long renderFrameIndex;
	private static volatile long lastDispatchRenderFrame = -1L;
	private static volatile long lastAppliedRenderFrame = -1L;
	private static volatile PlayerSample lastRealtimeDispatchSample;
	private static volatile double lastRealtimeDispatchTimeSeconds = Double.NaN;
	private static final GpuTimerQueries GPU_TIMERS = new GpuTimerQueries();

	@Override
	public void onInitializeClient() {
		WorldRenderEvents.START_MAIN.register(context -> GPU_TIMERS.onWorldRenderStart());
		HudElementRegistry.addFirst(class_2960.method_60655(MOD_ID, "frame_telemetry"), NpuXmxBridgeClient::sampleRenderTelemetry);
		HudElementRegistry.addLast(HUD_LAYER_ID, NpuXmxBridgeClient::renderShaderPreview);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ensureAssistTexture(client);
			tickTelemetry(client);
			while (RUN_SAMPLE_KEY.method_1436()) {
				toggleRealtime(client);
			}
			tickRealtime(client);
		});

		LOGGER.info(
			"NPU XMX Bridge client initialized with {} transport. Press N to toggle real-time NPU assist feed at {} ms cadence, {}-frame reuse, and {}-frame max assist age.",
			BRIDGE_CLIENT.transportName(),
			UPDATE_INTERVAL_MS,
			UPDATE_EVERY_N_FRAMES,
			MAX_ASSIST_AGE_FRAMES
		);
	}

	private static void toggleRealtime(class_310 client) {
		if (client.field_1724 == null) {
			return;
		}

		if (assistMode == AssistMode.OFF) {
			beginWarmup(client);
			return;
		}

		boolean wasActive = assistMode == AssistMode.ACTIVE;
		disableAssist(client, wasActive ? "NPU shader assist disabled." : "NPU shader assist warm-up canceled.");
	}

	private static void tickTelemetry(class_310 client) {
		if (client.field_1724 == null) {
			return;
		}

		long now = System.nanoTime();
		if (lastTelemetryHeartbeatAtNanos != 0L && now - lastTelemetryHeartbeatAtNanos < 1_000_000_000L) {
			return;
		}
		lastTelemetryHeartbeatAtNanos = now;

		AssistTelemetryLogger logger = telemetryLogger(client);
		if (logger == null || !logger.isEnabled()) {
			return;
		}

		logger.logHeartbeat(
			client,
			assistMode == AssistMode.ACTIVE,
			BRIDGE_CLIENT.transportName(),
			shaderFrameReady,
			REQUEST_IN_FLIGHT.get(),
			assistStateName(),
			currentAssistAgeFrames(),
			assistUpdatedThisFrame(),
			warmupRemaining,
			USE_VANILLA_POST_EFFECT,
			GPU_TIMERS.snapshot()
		);
	}

	private static void tickRealtime(class_310 client) {
		if (client.field_1724 == null) {
			return;
		}

		if (assistMode == AssistMode.OFF) {
			return;
		}

		if (assistMode == AssistMode.ACTIVE && USE_VANILLA_POST_EFFECT) {
			ensureHybridPostEffect(client);
		}
		showOverlayStatus(client, overlayStatus.message(), overlayStatus.color());

		long now = System.nanoTime();
		if (REQUEST_IN_FLIGHT.get()) {
			return;
		}

		if (assistMode == AssistMode.WARMING_UP) {
			runBridgeSample(client, now, DispatchKind.WARMUP, assistGeneration);
			return;
		}

		if (!shouldDispatchRealtime(client, now)) {
			return;
		}

		runBridgeSample(client, now, DispatchKind.REALTIME, assistGeneration);
	}

	private static void runBridgeSample(class_310 client, long startedAtNanos, DispatchKind dispatchKind, long generation) {
		if (!REQUEST_IN_FLIGHT.compareAndSet(false, true)) {
			return;
		}

		lastDispatchAtNanos = startedAtNanos;
		lastDispatchRenderFrame = renderFrameIndex;
		PlayerSample sample = PlayerSample.capture(client);
		double timeSeconds = client.field_1687 != null ? client.field_1687.method_75260() / 20.0 : frameSequence / 20.0;
		if (dispatchKind == DispatchKind.REALTIME) {
			lastRealtimeDispatchSample = sample;
			lastRealtimeDispatchTimeSeconds = timeSeconds;
		}
		ShaderFrameRequest request = new ShaderFrameRequest(sample, timeSeconds, SHADER_TILE_SIZE, SHADER_TILE_SIZE);
		long currentFrame = dispatchKind == DispatchKind.REALTIME ? ++frameSequence : frameSequence;
		if (dispatchKind == DispatchKind.WARMUP) {
			overlayStatus = new OverlayStatus(
				String.format(
					Locale.ROOT,
					"Warming up NPU assist (%d/%d)...",
					Math.max(0, WARMUP_REQUESTS - warmupRemaining + 1),
					Math.max(1, WARMUP_REQUESTS)
				),
				class_124.field_1065
			);
		} else {
			overlayStatus = new OverlayStatus("NPU shader assist frame in flight...", class_124.field_1062);
		}

		CompletableFuture
			.supplyAsync(() -> BRIDGE_CLIENT.runShaderFrame(request), BRIDGE_EXECUTOR)
			.whenComplete((frame, error) -> client.execute(() -> {
				REQUEST_IN_FLIGHT.set(false);
				if (generation != assistGeneration || assistMode == AssistMode.OFF) {
					return;
				}
				if (error != null) {
					Throwable cause = error.getCause() != null ? error.getCause() : error;
					LOGGER.warn("Bridge sample failed", cause);
					disableAssistInternal(client, false);
					logError(client, currentFrame, request, cause);
					overlayStatus = new OverlayStatus("Bridge call failed: " + cause.getMessage(), class_124.field_1061);
					showChatStatus(client, overlayStatus.message(), overlayStatus.color());
					return;
				}

				if (dispatchKind == DispatchKind.WARMUP) {
					handleWarmupCompletion(client, request, frame, generation);
					return;
				}

				applyShaderFrame(client, frame);
				logFrame(client, currentFrame, request, frame);
				overlayStatus = new OverlayStatus(frame.statusLine(), class_124.field_1075);
			}));
	}

	private static void beginWarmup(class_310 client) {
		assistGeneration++;
		assistMode = AssistMode.WARMING_UP;
		warmupRemaining = WARMUP_REQUESTS;
		lastDispatchAtNanos = 0L;
		lastDispatchRenderFrame = -1L;
		lastAppliedRenderFrame = -1L;
		lastRealtimeDispatchSample = null;
		lastRealtimeDispatchTimeSeconds = Double.NaN;
		frameSequence = 0L;
		shaderFrameReady = false;
		ensureShaderTexture(client, shaderTextureWidth, shaderTextureHeight);
		resetShaderTexture(client);
		overlayStatus = new OverlayStatus(
			WARMUP_REQUESTS > 0
				? String.format(Locale.ROOT, "Warming up NPU assist (%d requests)...", WARMUP_REQUESTS)
				: "Preparing NPU shader assist...",
			class_124.field_1065
		);
		showChatStatus(client, overlayStatus.message(), overlayStatus.color());
		if (WARMUP_REQUESTS == 0) {
			activateRealtime(client);
		}
	}

	private static void activateRealtime(class_310 client) {
		assistMode = AssistMode.ACTIVE;
		warmupRemaining = 0;
		lastDispatchAtNanos = 0L;
		lastDispatchRenderFrame = -1L;
		lastRealtimeDispatchSample = null;
		lastRealtimeDispatchTimeSeconds = Double.NaN;
		if (USE_VANILLA_POST_EFFECT) {
			enableHybridPostEffect(client);
		}
		overlayStatus = new OverlayStatus(
			String.format(
				Locale.ROOT,
				USE_VANILLA_POST_EFFECT
					? "Vanilla post-effect NPU assist enabled via %s (%d ms, every %d frames)."
					: "Iris shaderpack NPU assist enabled via %s (%d ms, every %d frames).",
				BRIDGE_CLIENT.transportName(),
				UPDATE_INTERVAL_MS,
				UPDATE_EVERY_N_FRAMES
			),
			class_124.field_1060
		);
		showChatStatus(client, overlayStatus.message(), overlayStatus.color());
		logToggle(client, true);
	}

	private static void handleWarmupCompletion(class_310 client, ShaderFrameRequest request, ShaderFrameResult frame, long generation) {
		if (generation != assistGeneration || assistMode != AssistMode.WARMING_UP) {
			return;
		}

		if (warmupRemaining > 0) {
			warmupRemaining--;
		}
		if (warmupRemaining > 0) {
			overlayStatus = new OverlayStatus(
				String.format(
					Locale.ROOT,
					"Warming up NPU assist (%d/%d)...",
					WARMUP_REQUESTS - warmupRemaining,
					Math.max(1, WARMUP_REQUESTS)
				),
				class_124.field_1065
			);
			return;
		}

		LOGGER.info(
			"NPU assist warm-up complete at {} ms for {}x{} tile; entering decimated realtime mode.",
			String.format(Locale.ROOT, "%.3f", frame.elapsedMs()),
			request.width(),
			request.height()
		);
		activateRealtime(client);
	}

	private static boolean shouldDispatchRealtime(class_310 client, long now) {
		if (lastDispatchAtNanos != 0L && now - lastDispatchAtNanos < UPDATE_INTERVAL_MS * 1_000_000L) {
			return false;
		}

		long assistAgeFrames = currentAssistAgeFrames();
		if (!shaderFrameReady || assistAgeFrames < 0L) {
			return true;
		}
		if (assistAgeFrames >= MAX_ASSIST_AGE_FRAMES) {
			return true;
		}
		if (lastDispatchRenderFrame >= 0L && renderFrameIndex - lastDispatchRenderFrame < UPDATE_EVERY_N_FRAMES) {
			return false;
		}

		PlayerSample currentSample = PlayerSample.capture(client);
		if (lastRealtimeDispatchSample == null) {
			return true;
		}

		double positionDelta = currentSample.distanceTo(lastRealtimeDispatchSample);
		double angleDelta = currentSample.maxAngleDeltaTo(lastRealtimeDispatchSample);
		if (positionDelta >= MIN_POSITION_DELTA || angleDelta >= MIN_ANGLE_DELTA) {
			return true;
		}

		double timeSeconds = client.field_1687 != null ? client.field_1687.method_75260() / 20.0 : frameSequence / 20.0;
		return Double.isNaN(lastRealtimeDispatchTimeSeconds)
			|| timeSeconds - lastRealtimeDispatchTimeSeconds >= Math.max(0.25, MAX_ASSIST_AGE_FRAMES / 20.0);
	}

	private static void disableAssist(class_310 client, String message) {
		boolean wasActive = assistMode == AssistMode.ACTIVE;
		disableAssistInternal(client, true);
		overlayStatus = new OverlayStatus(message, wasActive ? class_124.field_1054 : class_124.field_1080);
		showChatStatus(client, overlayStatus.message(), overlayStatus.color());
		if (wasActive) {
			logToggle(client, false);
		}
	}

	private static void disableAssistInternal(class_310 client, boolean resetStatusMessage) {
		assistGeneration++;
		assistMode = AssistMode.OFF;
		warmupRemaining = 0;
		shaderFrameReady = false;
		resetShaderTexture(client);
		GPU_TIMERS.clearUploadMetrics();
		lastDispatchRenderFrame = -1L;
		lastAppliedRenderFrame = -1L;
		lastRealtimeDispatchSample = null;
		lastRealtimeDispatchTimeSeconds = Double.NaN;
		if (USE_VANILLA_POST_EFFECT) {
			disableHybridPostEffect(client);
		}
		if (resetStatusMessage) {
			overlayStatus = new OverlayStatus("NPU shader assist disabled.", class_124.field_1054);
		}
	}

	private static void showChatStatus(class_310 client, String message, class_124 color) {
		if (client.field_1724 != null) {
			client.field_1724.method_7353(class_2561.method_43470(message).method_27692(color), false);
		}
	}

	private static void showOverlayStatus(class_310 client, String message, class_124 color) {
		if (client.field_1724 != null) {
			client.field_1724.method_7353(class_2561.method_43470(message).method_27692(color), true);
		}
	}

	private static NpuBridgeClient createBridgeClient() {
		String transport = System.getProperty("npuxmxbridge.transport", "socket").trim().toLowerCase(Locale.ROOT);
		if ("http".equals(transport)) {
			return new NpuBridgeHttpClient();
		}
		return new NpuBridgeSocketClient();
	}

	private static void applyShaderFrame(class_310 client, ShaderFrameResult frame) {
		int previewScale = Math.max(1, SHADER_PREVIEW_SCALE);
		int previewWidth = frame.width() * previewScale;
		int previewHeight = frame.height() * previewScale;
		ensureShaderTexture(client, previewWidth, previewHeight);
		synchronized (TEXTURE_LOCK) {
			if (shaderTexture == null) {
				return;
			}

			class_1011 pixels = shaderTexture.method_4525();
			if (pixels == null) {
				return;
			}

			int index = 0;
			for (int y = 0; y < frame.height(); y++) {
				for (int x = 0; x < frame.width(); x++) {
					int abgr = frame.pixelsAbgr()[index++];
					int baseX = x * previewScale;
					int baseY = y * previewScale;
					for (int offsetY = 0; offsetY < previewScale; offsetY++) {
						for (int offsetX = 0; offsetX < previewScale; offsetX++) {
							pixels.method_4305(baseX + offsetX, baseY + offsetY, abgr);
						}
					}
				}
			}
			GPU_TIMERS.measureUpload(shaderTexture::method_4524);
			shaderFrameReady = true;
			lastAppliedRenderFrame = renderFrameIndex;
		}
	}

	private static void enableHybridPostEffect(class_310 client) {
		if (SET_POST_EFFECT_METHOD == null) {
			return;
		}

		class_2960 current = client.field_1773.method_62906();
		if (POST_EFFECT_ID.equals(current)) {
			return;
		}
		if (current != null) {
			previousPostEffectId = current;
		}
		invokeSetPostEffect(client, POST_EFFECT_ID);
	}

	private static void ensureHybridPostEffect(class_310 client) {
		if (SET_POST_EFFECT_METHOD == null) {
			return;
		}
		class_2960 current = client.field_1773.method_62906();
		if (!POST_EFFECT_ID.equals(current)) {
			invokeSetPostEffect(client, POST_EFFECT_ID);
		}
	}

	private static void disableHybridPostEffect(class_310 client) {
		if (POST_EFFECT_ID.equals(client.field_1773.method_62906())) {
			client.field_1773.method_62905();
		}

		if (SET_POST_EFFECT_METHOD != null && previousPostEffectId != null && !POST_EFFECT_ID.equals(previousPostEffectId)) {
			invokeSetPostEffect(client, previousPostEffectId);
		}
		previousPostEffectId = null;
	}

	private static void invokeSetPostEffect(class_310 client, class_2960 postEffectId) {
		if (SET_POST_EFFECT_METHOD == null) {
			return;
		}

		try {
			SET_POST_EFFECT_METHOD.invoke(client.field_1773, postEffectId);
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Unable to activate post effect {}", postEffectId, exception);
		}
	}

	private static Method resolveSetPostEffectMethod() {
		try {
			Method method = net.minecraft.class_757.class.getDeclaredMethod("setPostEffect", class_2960.class);
			method.setAccessible(true);
			return method;
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Unable to access GameRenderer.setPostEffect; the optional vanilla post-effect demo path will stay disabled.", exception);
			return null;
		}
	}

	private static void ensureShaderTexture(class_310 client, int width, int height) {
		synchronized (TEXTURE_LOCK) {
			if (shaderTexture != null && shaderTextureWidth == width && shaderTextureHeight == height) {
				return;
			}

			if (shaderTexture != null) {
				client.method_1531().method_4615(SHADER_TEXTURE_ID);
				shaderTexture.close();
			}

			shaderTexture = new class_1043(() -> "npu_xmx_shader_preview", width, height, false);
			shaderTextureWidth = width;
			shaderTextureHeight = height;
			class_1011 pixels = shaderTexture.method_4525();
			if (pixels != null) {
				fillTexturePixels(pixels, width, height, NEUTRAL_ASSIST_ABGR);
				GPU_TIMERS.measureUpload(shaderTexture::method_4524);
			}
			client.method_1531().method_4616(SHADER_TEXTURE_ID, shaderTexture);
		}
	}

	private static void ensureAssistTexture(class_310 client) {
		ensureShaderTexture(client, shaderTextureWidth, shaderTextureHeight);
	}

	private static void resetShaderTexture(class_310 client) {
		ensureShaderTexture(client, shaderTextureWidth, shaderTextureHeight);
		synchronized (TEXTURE_LOCK) {
			if (shaderTexture == null) {
				return;
			}

			class_1011 pixels = shaderTexture.method_4525();
			if (pixels == null) {
				return;
			}

			fillTexturePixels(pixels, shaderTextureWidth, shaderTextureHeight, NEUTRAL_ASSIST_ABGR);
			GPU_TIMERS.measureUpload(shaderTexture::method_4524);
		}
	}

	private static void fillTexturePixels(class_1011 pixels, int width, int height, int abgr) {
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				pixels.method_4305(x, y, abgr);
			}
		}
	}

	private static AssistTelemetryLogger telemetryLogger(class_310 client) {
		if (telemetryInitFailed) {
			return null;
		}
		if (telemetryLogger != null) {
			return telemetryLogger;
		}

		synchronized (TEXTURE_LOCK) {
			if (telemetryLogger != null || telemetryInitFailed) {
				return telemetryLogger;
			}

			try {
				telemetryLogger = new AssistTelemetryLogger(client.field_1697);
				if (telemetryLogger.isEnabled()) {
					LOGGER.info("NPU assist telemetry logging to {}", telemetryLogger.logPath());
				}
			} catch (RuntimeException exception) {
				telemetryInitFailed = true;
				LOGGER.warn("Unable to initialize NPU assist telemetry logging", exception);
			}
			return telemetryLogger;
		}
	}

	private static void logToggle(class_310 client, boolean realtimeEnabled) {
		AssistTelemetryLogger logger = telemetryLogger(client);
		if (logger == null || !logger.isEnabled()) {
			return;
		}

		logger.logToggle(
			client,
			realtimeEnabled,
			BRIDGE_CLIENT.transportName(),
			UPDATE_INTERVAL_MS,
			assistStateName(),
			currentAssistAgeFrames(),
			assistUpdatedThisFrame(),
			warmupRemaining,
			USE_VANILLA_POST_EFFECT,
			SHADER_TILE_SIZE,
			GPU_TIMERS.snapshot()
		);
	}

	private static void logFrame(class_310 client, long sequence, ShaderFrameRequest request, ShaderFrameResult frame) {
		AssistTelemetryLogger logger = telemetryLogger(client);
		if (logger == null || !logger.isEnabled()) {
			return;
		}

		logger.logFrame(
			client,
			assistMode == AssistMode.ACTIVE,
			BRIDGE_CLIENT.transportName(),
			shaderFrameReady,
			REQUEST_IN_FLIGHT.get(),
			assistStateName(),
			currentAssistAgeFrames(),
			assistUpdatedThisFrame(),
			warmupRemaining,
			sequence,
			request,
			frame,
			USE_VANILLA_POST_EFFECT,
			GPU_TIMERS.snapshot()
		);
	}

	private static void logError(class_310 client, long sequence, ShaderFrameRequest request, Throwable error) {
		AssistTelemetryLogger logger = telemetryLogger(client);
		if (logger == null || !logger.isEnabled()) {
			return;
		}

		logger.logError(
			client,
			assistMode == AssistMode.ACTIVE,
			BRIDGE_CLIENT.transportName(),
			shaderFrameReady,
			REQUEST_IN_FLIGHT.get(),
			assistStateName(),
			currentAssistAgeFrames(),
			assistUpdatedThisFrame(),
			warmupRemaining,
			sequence,
			request,
			error,
			USE_VANILLA_POST_EFFECT,
			GPU_TIMERS.snapshot()
		);
	}

	private static void sampleRenderTelemetry(class_332 context, net.minecraft.class_9779 tickCounter) {
		renderFrameIndex++;
		GPU_TIMERS.onHudRender();
	}

	private static void renderShaderPreview(class_332 context, net.minecraft.class_9779 tickCounter) {
		if (!SHOW_PREVIEW_HUD || assistMode != AssistMode.ACTIVE || !shaderFrameReady || SHADER_PREVIEW_SCALE <= 0) {
			return;
		}

		int previewWidth = shaderTextureWidth;
		int previewHeight = shaderTextureHeight;
		int x = context.method_51421() - previewWidth - 12;
		int y = 12;

		context.method_25294(x - 4, y - 4, x + previewWidth + 4, y + previewHeight + 18, 0x8A000000);
		context.method_25290(
			class_10799.field_56883,
			SHADER_TEXTURE_ID,
			x,
			y,
			0.0F,
			0.0F,
			previewWidth,
			previewHeight,
			previewWidth,
			previewHeight
		);
		context.method_51433(class_310.method_1551().field_1772, "NPU shader preview", x, y + previewHeight + 4, 0xE8F7FF, false);
	}

	static record PlayerSample(double x, double y, double z, double yaw, double pitch) {
		private static PlayerSample capture(class_310 client) {
			return new PlayerSample(
				client.field_1724.method_23317(),
				client.field_1724.method_23318(),
				client.field_1724.method_23321(),
				client.field_1724.method_36454(),
				client.field_1724.method_36455()
			);
		}

		private double distanceTo(PlayerSample other) {
			double dx = x - other.x;
			double dy = y - other.y;
			double dz = z - other.z;
			return Math.sqrt(dx * dx + dy * dy + dz * dz);
		}

		private double maxAngleDeltaTo(PlayerSample other) {
			return Math.max(wrappedAngleDelta(yaw, other.yaw), wrappedAngleDelta(pitch, other.pitch));
		}
	}

	private static String assistStateName() {
		return assistMode.name().toLowerCase(Locale.ROOT);
	}

	private static long currentAssistAgeFrames() {
		if (!shaderFrameReady || lastAppliedRenderFrame < 0L) {
			return -1L;
		}
		return Math.max(0L, renderFrameIndex - lastAppliedRenderFrame);
	}

	private static boolean assistUpdatedThisFrame() {
		return shaderFrameReady && lastAppliedRenderFrame >= 0L && renderFrameIndex == lastAppliedRenderFrame;
	}

	private enum AssistMode {
		OFF,
		WARMING_UP,
		ACTIVE
	}

	private enum DispatchKind {
		WARMUP,
		REALTIME
	}

	private static double getDoubleProperty(String name, double fallback) {
		String value = System.getProperty(name);
		if (value == null || value.isBlank()) {
			return fallback;
		}
		try {
			return Double.parseDouble(value);
		} catch (NumberFormatException exception) {
			LOGGER.warn("Invalid double system property {}={}; using {}", name, value, fallback);
			return fallback;
		}
	}

	private static double wrappedAngleDelta(double a, double b) {
		double delta = Math.abs(a - b) % 360.0;
		return delta > 180.0 ? 360.0 - delta : delta;
	}

	private static record OverlayStatus(String message, class_124 color) { }
}
